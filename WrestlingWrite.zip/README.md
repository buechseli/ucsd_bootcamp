## Wrestling with data

### Instructions

* Create a script that will loop through four years of wrestling data.

* Create a new updated verson of data for each year.

* The updated version should contain:

  * Wrestlers name
  * Wins
  * Win Percentage
  * Losses
  * Loss Percentage
  * Draws
  * Draw percentage

* Add headers to the first row of each updated data sheet.
